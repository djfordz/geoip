<?php

namespace Dford\Geoip\Controller;

abstract class LoginHistoryAbstract extends \Magento\Framework\App\Action\Action
{

}
